from django.apps import AppConfig
from django.contrib import admin
from student.models import UserProfileInfo, User
# Register your models here.
admin.site.register(UserProfileInfo)

class StudentConfig(AppConfig):
    name = 'student'

