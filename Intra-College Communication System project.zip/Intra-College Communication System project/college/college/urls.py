import django.contrib
from django.urls import path
from django.conf.urls import url, include
from student import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('admin/', django.contrib.admin.site.urls),
    url(r'^$', views.index, name='index'),
    url(r'^special/', views.special, name='special'),
    url(r'^student/', include('student.urls')),
    url(r'^logout/$', views.user_logout, name='logout'),
    url(r'^success/$', views.success, name='success'),
    url(r'^index/$', views.index, name='index'),
    url(r'^email2/$', views.tryView, name='email2'),
    url(r'^email3/$', views.tryView2, name='email3'),
    url(r'^email/$',views.emailView, name='email'),
    url(r'^loginnext/$',views.loginnext, name='loginnext'),
    url(r'^sms/$', views.sms, name='sms'),
    url(r'^user_login2/$', views.user_login2, name='user_login2'),
    url(r'^index2/$', views.index2, name='index2'),
    url(r'^success2/$', views.success2, name='success2'),
    url(r'^success3/$',views.success3, name='success3'),

]
